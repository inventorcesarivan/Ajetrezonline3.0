Ajetrez — Root-Prefixed Bundle

Cómo usar
1) Sube *todo* el contenido de esta carpeta a tu sitio Netlify.
2) Apunta tu navegador a: https://TU-SITIO.netlify.app/index.html
3) Los botones "Clásico" cambian el iframe a páginas dentro de /AjetrezFinal3.0-main.
4) Los links "Online" abren cada modo con import desde /AjetrezFinal3.0-main/web/online.js

Verificación
- Abre directamente /AjetrezFinal3.0-main/web/online.js en el navegador. No debe dar 404.
