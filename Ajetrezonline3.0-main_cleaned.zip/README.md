
Ajetrez Online (Supabase MVP) v2 — online.js ignora jugadas propias al recibir realtime.
